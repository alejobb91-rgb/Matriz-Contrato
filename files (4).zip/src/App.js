import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";

// --- To-Do List Page ---
function getTodosFromStorage() {
  const local = localStorage.getItem("todos");
  return local ? JSON.parse(local) : [];
}

function TodoPage() {
  const [todos, setTodos] = useState(getTodosFromStorage());
  const [input, setInput] = useState("");

  useEffect(() => {
    localStorage.setItem("todos", JSON.stringify(todos));
  }, [todos]);

  const addTodo = (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    setTodos([...todos, { text: input, done: false }]);
    setInput("");
  };

  const toggleTodo = (idx) => {
    setTodos(
      todos.map((todo, i) =>
        i === idx ? { ...todo, done: !todo.done } : todo
      )
    );
  };

  const removeTodo = (idx) => {
    setTodos(todos.filter((_, i) => i !== idx));
  };

  const clearAll = () => setTodos([]);

  return (
    <div style={{ maxWidth: 400, margin: "40px auto", padding: 24, border: "1px solid #ddd", borderRadius: 8 }}>
      <h2>To-Do List</h2>
      <form onSubmit={addTodo} style={{ display: "flex", marginBottom: 16 }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Add a new task"
          style={{ flex: 1, marginRight: 8 }}
        />
        <button type="submit">Add</button>
      </form>
      <ul style={{ padding: 0, listStyle: "none" }}>
        {todos.map((todo, idx) => (
          <li key={idx} style={{
            display: "flex",
            alignItems: "center",
            marginBottom: 8,
            background: "#fafafa",
            padding: 8,
            borderRadius: 4,
            textDecoration: todo.done ? "line-through" : "none"
          }}>
            <input
              type="checkbox"
              checked={todo.done}
              onChange={() => toggleTodo(idx)}
              style={{ marginRight: 8 }}
            />
            <span style={{ flex: 1 }}>{todo.text}</span>
            <button
              onClick={() => removeTodo(idx)}
              style={{ marginLeft: 8, color: "#c00", border: "none", background: "transparent", cursor: "pointer" }}
              aria-label="Remove"
            >✗</button>
          </li>
        ))}
      </ul>
      {todos.length > 0 && (
        <button onClick={clearAll} style={{ marginTop: 16, color: "#666" }}>
          Clear All
        </button>
      )}
    </div>
  );
}

// --- Home Page ---
function Home() {
  return (
    <div style={{ padding: 32 }}>
      <h1>Welcome</h1>
      <ul>
        <li>
          <Link to="/todo">To-Do List App</Link>
        </li>
      </ul>
    </div>
  );
}

// --- App Router ---
export default function App() {
  return (
    <Router>
      <nav style={{ padding: 10, background: "#f4f4f4" }}>
        <Link to="/" style={{ marginRight: 10 }}>Home</Link>
        <Link to="/todo">To-Do List</Link>
      </nav>
      <Switch>
        <Route path="/" exact component={Home} />
        <Route path="/todo" component={TodoPage} />
      </Switch>
    </Router>
  );
}