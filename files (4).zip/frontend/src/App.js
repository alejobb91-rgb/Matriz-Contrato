import React, { useState, useEffect } from "react";
import ContratoForm from "./components/ContratoForm";
import ContratoList from "./components/ContratoList";

const API = "http://localhost:4000/api/contratos";

export default function App() {
  const [contratos, setContratos] = useState([]);
  const [editing, setEditing] = useState(null);

  // Cargar contratos
  useEffect(() => {
    fetch(API)
      .then(res => res.json())
      .then(setContratos);
  }, []);

  // Crear o actualizar contrato
  const handleSave = async (contrato) => {
    if (editing) {
      const res = await fetch(`${API}/${editing._id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(contrato),
      });
      const updated = await res.json();
      setContratos(contratos.map(c => c._id === updated._id ? updated : c));
      setEditing(null);
    } else {
      const res = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(contrato),
      });
      const nuevo = await res.json();
      setContratos([nuevo, ...contratos]);
    }
  };

  // Eliminar contrato
  const handleDelete = async (id) => {
    if (window.confirm("¿Seguro de eliminar este contrato?")) {
      await fetch(`${API}/${id}`, { method: "DELETE" });
      setContratos(contratos.filter(c => c._id !== id));
    }
  };

  // Editar contrato
  const handleEdit = (contrato) => setEditing(contrato);

  return (
    <div style={{ maxWidth: 700, margin: "40px auto", padding: 24 }}>
      <h1>Control de Contratos</h1>
      <ContratoForm
        key={editing ? editing._id : "new"}
        onSave={handleSave}
        contrato={editing}
        onCancel={() => setEditing(null)}
      />
      <ContratoList
        contratos={contratos}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />
    </div>
  );
}