import React from 'react';
import { View, Text } from 'react-native';

export default function ContratoListScreen() {
  return (
    <View>
      <Text>Lista de Contratos</Text>
      {/* Aquí iría el FlatList de contratos */}
    </View>
  );
}