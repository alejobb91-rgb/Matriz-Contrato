const mongoose = require('mongoose');

const ContratoSchema = new mongoose.Schema({
  numero: { type: String, required: true, unique: true },
  objeto: { type: String, required: true },
  contratista: { type: String, required: true },
  fechaInicio: { type: String, required: true },
  fechaFin: { type: String, required: true },
  valor: { type: Number, required: true }
}, { timestamps: true });

module.exports = mongoose.model('Contrato', ContratoSchema);