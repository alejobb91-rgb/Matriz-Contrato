const mongoose = require('mongoose');

const ContractSchema = new mongoose.Schema({
  nombre: String,
  cliente: String,
  fechaInicio: Date,
  fechaFin: Date,
  monto: Number,
  estado: String,
  notas: String,
  archivoAdjuntoUrl: String,
  tipo: String,
});

module.exports = mongoose.model('Contract', ContractSchema);