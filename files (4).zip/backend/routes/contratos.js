const express = require('express');
const Contrato = require('../models/Contrato');
const router = express.Router();

// Obtener todos los contratos
router.get('/', async (req, res) => {
  const contratos = await Contrato.find().sort({ createdAt: -1 });
  res.json(contratos);
});

// Crear nuevo contrato
router.post('/', async (req, res) => {
  try {
    const contrato = new Contrato(req.body);
    await contrato.save();
    res.status(201).json(contrato);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Actualizar contrato
router.put('/:id', async (req, res) => {
  try {
    const contrato = await Contrato.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(contrato);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Eliminar contrato
router.delete('/:id', async (req, res) => {
  try {
    await Contrato.findByIdAndDelete(req.params.id);
    res.json({ msg: 'Contrato eliminado' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;