const Contract = require('../models/Contract');
const generatePDF = require('../utils/generatePDF');

exports.getAllContracts = async (req, res) => {
  const contracts = await Contract.find();
  res.json(contracts);
};

exports.createContract = async (req, res) => {
  const contract = new Contract(req.body);
  await contract.save();
  res.status(201).json(contract);
};

exports.getContractPDF = async (req, res) => {
  const contract = await Contract.findById(req.params.id);
  if (!contract) return res.status(404).send('No encontrado');
  res.setHeader('Content-Type', 'application/pdf');
  generatePDF(contract, res);
};