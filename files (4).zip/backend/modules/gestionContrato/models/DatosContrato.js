const mongoose = require('mongoose');

const DatosContratoSchema = new mongoose.Schema({
  numeroContrato: { type: String, required: true, unique: true },
  localidad: { type: String, required: true },
  upz: { type: String, required: true },
  barrio: { type: String, required: true },
  poblacionBeneficiada: { type: Number, required: true },
  fechaInicioContrato: { type: Date, required: true },
  fechaFinalizacionContrato: { type: Date, required: true },
  direccionPuntoIDU: { type: String, required: true },
  correoPuntoIDU: {
    type: String,
    required: true,
    match: [/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, 'Correo inválido']
  },
  telefonoPuntoIDU: { type: String, required: true }
});

module.exports = mongoose.model('DatosContrato', DatosContratoSchema);