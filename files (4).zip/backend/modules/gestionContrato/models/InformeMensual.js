const mongoose = require('mongoose');

const InformeMensualSchema = new mongoose.Schema({
  numeroContrato: { type: String, required: true },
  numeroMemorandoEntrada: { type: String, required: true, match: [/^[0-9]+$/, 'Solo números'] },
  fechaMemorandoEntrada: { type: Date, required: true },
  numeroInformeMensual: { type: String, required: true, unique: true },
  version: { type: String, required: true },
  numeroMemorandoSalida: { type: String, required: true, match: [/^[0-9]+$/, 'Solo números'] },
  fechaMemorandoSalida: { type: Date, required: true }
});

module.exports = mongoose.model('InformeMensual', InformeMensualSchema);