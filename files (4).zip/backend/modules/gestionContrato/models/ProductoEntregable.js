const mongoose = require('mongoose');

const ProductoEntregableSchema = new mongoose.Schema({
  numeroContrato: { type: String, required: true },
  productoEntregado: { type: String, required: true },
  numeroMemorandoEntrada: { type: String, required: true, match: [/^[0-9]+$/, 'Solo números'] },
  fechaEntrega: { type: Date, required: true }
});

module.exports = mongoose.model('ProductoEntregable', ProductoEntregableSchema);