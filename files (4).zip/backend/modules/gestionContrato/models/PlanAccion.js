const mongoose = require('mongoose');

const PlanAccionSchema = new mongoose.Schema({
  numeroContrato: { type: String, required: true },
  numeroMemorandoEntrada: { type: String, required: true, match: [/^[0-9]+$/, 'Solo números'] },
  numeroInforme: { type: String, required: true, unique: true },
  fechaPlanAccion: { type: Date, required: true }
});

module.exports = mongoose.model('PlanAccion', PlanAccionSchema);