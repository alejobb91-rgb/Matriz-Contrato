const mongoose = require('mongoose');

const EstadoContratoSchema = new mongoose.Schema({
  numeroContrato: { type: String, required: true, unique: true },
  estado: { type: String, enum: ['Activo', 'Suspendido'], required: true },
  etapa: {
    type: String,
    enum: [
      'Construcción', 'Conservación', 'Estudios y Diseños', 'Factibilidad',
      'Estudios y Diseños In House', 'Estructuración', 'Factibilidad In House', 'Liquidación Construccción'
    ]
  },
  fechaInicioSuspension: { type: Date },
  fechaFinalizacionSuspension: { type: Date },
  razonSuspension: { type: String }
});

module.exports = mongoose.model('EstadoContrato', EstadoContratoSchema);