const DatosContrato = require('../models/DatosContrato');
const { validarDatosContrato } = require('../validations/datosContratoValidation');

exports.crearDatosContrato = async (req, res) => {
  const errores = validarDatosContrato(req.body);
  if (errores.length) return res.status(400).json({ errores });
  try {
    const datosContrato = new DatosContrato(req.body);
    await datosContrato.save();
    res.status(201).json({ message: 'Datos de contrato creados', datosContrato });
  } catch (err) {
    res.status(500).json({ errores: ['Error al crear los datos de contrato'] });
  }
};