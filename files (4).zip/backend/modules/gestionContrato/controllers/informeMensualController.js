const InformeMensual = require('../models/InformeMensual');
const { validarInformeMensual } = require('../validations/informeMensualValidation');

exports.crearInformeMensual = async (req, res) => {
  const errores = validarInformeMensual(req.body);
  if (errores.length) return res.status(400).json({ errores });
  try {
    const existe = await InformeMensual.findOne({ numeroInformeMensual: req.body.numeroInformeMensual });
    if (existe) return res.status(400).json({ errores: ['No. Informe Mensual ya existe.'] });
    const informeMensual = new InformeMensual(req.body);
    await informeMensual.save();
    res.status(201).json({ message: 'Informe mensual creado', informeMensual });
  } catch (err) {
    res.status(500).json({ errores: ['Error al crear el informe mensual'] });
  }
};