const EstadoContrato = require('../models/EstadoContrato');
const { validarEstadoContrato } = require('../validations/estadoContratoValidation');

exports.crearEstadoContrato = async (req, res) => {
  const errores = validarEstadoContrato(req.body);
  if (errores.length) return res.status(400).json({ errores });
  try {
    const estadoContrato = new EstadoContrato(req.body);
    await estadoContrato.save();
    res.status(201).json({ message: 'Estado del contrato guardado', estadoContrato });
  } catch (err) {
    res.status(500).json({ errores: ['Error al guardar el estado del contrato'] });
  }
};