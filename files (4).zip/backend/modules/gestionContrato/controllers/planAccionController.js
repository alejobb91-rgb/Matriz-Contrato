const PlanAccion = require('../models/PlanAccion');
const { validarPlanAccion } = require('../validations/planAccionValidation');

exports.crearPlanAccion = async (req, res) => {
  const errores = validarPlanAccion(req.body);
  if (errores.length) return res.status(400).json({ errores });
  try {
    const existe = await PlanAccion.findOne({ numeroInforme: req.body.numeroInforme });
    if (existe) return res.status(400).json({ errores: ['No. Informe ya existe.'] });
    const planAccion = new PlanAccion(req.body);
    await planAccion.save();
    res.status(201).json({ message: 'Plan de Acción creado', planAccion });
  } catch (err) {
    res.status(500).json({ errores: ['Error al crear el Plan de Acción'] });
  }
};