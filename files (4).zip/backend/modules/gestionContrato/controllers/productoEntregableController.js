const ProductoEntregable = require('../models/ProductoEntregable');
const { validarProductoEntregable } = require('../validations/productoEntregableValidation');

exports.crearProductoEntregable = async (req, res) => {
  const errores = validarProductoEntregable(req.body);
  if (errores.length) return res.status(400).json({ errores });
  try {
    const productoEntregable = new ProductoEntregable(req.body);
    await productoEntregable.save();
    res.status(201).json({ message: 'Producto entregable creado', productoEntregable });
  } catch (err) {
    res.status(500).json({ errores: ['Error al crear el producto entregable'] });
  }
};