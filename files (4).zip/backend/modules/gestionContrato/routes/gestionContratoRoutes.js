const express = require('express');
const router = express.Router();
const datosContratoCtrl = require('../controllers/datosContratoController');
const planAccionCtrl = require('../controllers/planAccionController');
const productoEntregableCtrl = require('../controllers/productoEntregableController');
const informeMensualCtrl = require('../controllers/informeMensualController');
const estadoContratoCtrl = require('../controllers/estadoContratoController');

router.post('/datos-contrato', datosContratoCtrl.crearDatosContrato);
router.post('/plan-accion', planAccionCtrl.crearPlanAccion);
router.post('/producto-entregable', productoEntregableCtrl.crearProductoEntregable);
router.post('/informe-mensual', informeMensualCtrl.crearInformeMensual);
router.post('/estado-contrato', estadoContratoCtrl.crearEstadoContrato);

module.exports = router;