function validarProductoEntregable(data) {
  const errores = [];
  if (!data.numeroContrato) errores.push('No. Contrato es obligatorio');
  if (!data.productoEntregado) errores.push('Producto Entregado es obligatorio');
  if (!data.numeroMemorandoEntrada || !/^[0-9]+$/.test(data.numeroMemorandoEntrada)) errores.push('No. Memorando Entrada solo números');
  if (!data.fechaEntrega) errores.push('Fecha Entrega es obligatoria');
  return errores;
}
module.exports = { validarProductoEntregable };