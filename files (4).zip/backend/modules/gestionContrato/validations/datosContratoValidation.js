function validarDatosContrato(data) {
  const errores = [];
  if (!data.numeroContrato) errores.push('No. Contrato es obligatorio');
  if (!data.localidad) errores.push('Localidad es obligatoria');
  if (!data.upz) errores.push('UPZ es obligatoria');
  if (!data.barrio) errores.push('Barrio es obligatorio');
  if (!data.poblacionBeneficiada || isNaN(Number(data.poblacionBeneficiada))) errores.push('Población Beneficiada debe ser numérica');
  if (!data.fechaInicioContrato) errores.push('Fecha Inicio Contrato es obligatoria');
  if (!data.fechaFinalizacionContrato) errores.push('Fecha Finalización Contrato es obligatoria');
  if (!data.direccionPuntoIDU) errores.push('Dirección Punto IDU es obligatoria');
  if (!data.correoPuntoIDU || !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(data.correoPuntoIDU)) errores.push('Correo Punto IDU inválido');
  if (!data.telefonoPuntoIDU) errores.push('No. Telefónico Punto IDU es obligatorio');
  return errores;
}
module.exports = { validarDatosContrato };