function validarPlanAccion(data) {
  const errores = [];
  if (!data.numeroContrato) errores.push('No. Contrato es obligatorio');
  if (!data.numeroMemorandoEntrada || !/^[0-9]+$/.test(data.numeroMemorandoEntrada)) errores.push('No. Memorando Entrada solo números');
  if (!data.numeroInforme) errores.push('No. Informe es obligatorio');
  if (!data.fechaPlanAccion) errores.push('Fecha Plan de Acción es obligatoria');
  return errores;
}
module.exports = { validarPlanAccion };