function validarEstadoContrato(data) {
  const errores = [];
  if (!data.numeroContrato) errores.push('No. Contrato es obligatorio');
  if (!data.estado || !['Activo', 'Suspendido'].includes(data.estado)) errores.push('Estado es obligatorio y válido');
  if (data.estado === 'Activo' && !data.etapa) errores.push('Debe seleccionar Etapa');
  if (data.estado === 'Suspendido') {
    if (!data.fechaInicioSuspension) errores.push('Fecha Inicio Suspensión es obligatoria');
    if (!data.fechaFinalizacionSuspension) errores.push('Fecha Finalización Suspensión es obligatoria');
    if (!data.razonSuspension) errores.push('Razón de la Suspensión es obligatoria');
  }
  return errores;
}
module.exports = { validarEstadoContrato };