const express = require('express');
const router = express.Router();
const contratoController = require('../controllers/contratoController');
const renovacionController = require('../controllers/renovacionController');

// Contrato principal
router.get('/', contratoController.getAllContratos);
router.post('/', contratoController.createContrato);

// Submódulo: Renovaciones
router.get('/:id/renovaciones', renovacionController.getRenovacionesByContrato);
router.post('/:id/renovaciones', renovacionController.addRenovacion);

module.exports = router;