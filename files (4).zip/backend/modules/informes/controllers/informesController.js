const PDFDocument = require('pdfkit');
const ExcelJS = require('exceljs');
const DatosContrato = require('../../gestionContrato/models/DatosContrato');
const PlanAccion = require('../../gestionContrato/models/PlanAccion');
const ProductoEntregable = require('../../gestionContrato/models/ProductoEntregable');
const InformeMensual = require('../../gestionContrato/models/InformeMensual');
const EstadoContrato = require('../../gestionContrato/models/EstadoContrato');
const SocialIDU = require('../../asociar/models/SocialIDU');
const SocialInterventoria = require('../../asociar/models/SocialInterventoria');
const SocialObra = require('../../asociar/models/SocialObra');
const TecnicoIDU = require('../../asociar/models/TecnicoIDU');
const SituacionCritica = require('../../situacionesCriticas/models/SituacionCritica');

// Utilidad: Trae todos los datos relacionados a un contrato
async function getAllData(noContrato) {
  return {
    datosContrato: await DatosContrato.findOne({ numeroContrato: noContrato }).lean(),
    planAccion: await PlanAccion.find({ numeroContrato: noContrato }).lean(),
    productosEntregables: await ProductoEntregable.find({ numeroContrato: noContrato }).lean(),
    informesMensuales: await InformeMensual.find({ numeroContrato: noContrato }).lean(),
    estadoContrato: await EstadoContrato.findOne({ numeroContrato: noContrato }).lean(),
    socialIDU: await SocialIDU.find({ numeroContrato: noContrato }).lean(),
    socialInterventoria: await SocialInterventoria.find({ numeroContrato: noContrato }).lean(),
    socialObra: await SocialObra.find({ numeroContrato: noContrato }).lean(),
    tecnicoIDU: await TecnicoIDU.find({ numeroContrato: noContrato }).lean(),
    situacionesCriticas: await SituacionCritica.find({ numeroContrato: noContrato }).lean()
  };
}

// Submódulo Informe General del Proyecto - PDF/Excel
exports.informeGeneral = async (req, res) => {
  const { numeroContrato, formato } = req.query;
  if (!numeroContrato) return res.status(400).json({ error: 'No. Contrato requerido' });

  const data = await getAllData(numeroContrato);

  if (formato === 'pdf') {
    // PDF
    const doc = new PDFDocument();
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=InformeGeneral_${numeroContrato}.pdf`);
    doc.pipe(res);
    doc.fontSize(16).text(`Informe General del Proyecto - Contrato ${numeroContrato}`, { underline: true });
    Object.entries(data).forEach(([key, val]) => {
      doc.moveDown().fontSize(14).text(key.toUpperCase());
      doc.fontSize(10).text(JSON.stringify(val, null, 2));
    });
    doc.end();
  } else {
    // Excel por defecto
    const wb = new ExcelJS.Workbook();
    wb.creator = 'Sistema Informes';
    wb.created = new Date();
    Object.entries(data).forEach(([section, val]) => {
      const ws = wb.addWorksheet(section);
      if (Array.isArray(val) && val.length > 0) {
        ws.columns = Object.keys(val[0]).map(k => ({ header: k, key: k }));
        val.forEach(row => ws.addRow(row));
      } else if (typeof val === 'object' && val) {
        ws.columns = Object.keys(val).map(k => ({ header: k, key: k }));
        ws.addRow(val);
      }
    });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=InformeGeneral_${numeroContrato}.xlsx`);
    await wb.xlsx.write(res);
    res.end();
  }
};

// Submódulo Informe Proyectos - Solo Excel
exports.informeProyectoExcel = async (req, res) => {
  const { numeroContrato } = req.query;
  if (!numeroContrato) return res.status(400).json({ error: 'No. Contrato requerido' });

  const data = await getAllData(numeroContrato);
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Sistema Informes';
  wb.created = new Date();
  Object.entries(data).forEach(([section, val]) => {
    const ws = wb.addWorksheet(section);
    if (Array.isArray(val) && val.length > 0) {
      ws.columns = Object.keys(val[0]).map(k => ({ header: k, key: k }));
      val.forEach(row => ws.addRow(row));
    } else if (typeof val === 'object' && val) {
      ws.columns = Object.keys(val).map(k => ({ header: k, key: k }));
      ws.addRow(val);
    }
  });
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename=InformeProyecto_${numeroContrato}.xlsx`);
  await wb.xlsx.write(res);
  res.end();
};