const express = require('express');
const router = express.Router();
const informesCtrl = require('../controllers/informesController');

// Informe General del Proyecto (PDF o Excel)
router.get('/general', informesCtrl.informeGeneral);

// Informe Proyectos (Excel)
router.get('/proyectos', informesCtrl.informeProyectoExcel);

module.exports = router;