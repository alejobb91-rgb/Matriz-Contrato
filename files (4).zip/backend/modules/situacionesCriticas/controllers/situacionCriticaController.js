const SituacionCritica = require('../models/SituacionCritica');
const { validarSituacionCritica } = require('../validations/situacionCriticaValidation');

exports.crearSituacionCritica = async (req, res) => {
  const errores = validarSituacionCritica(req.body);
  if (errores.length) return res.status(400).json({ errores });
  try {
    const situacion = new SituacionCritica(req.body);
    await situacion.save();
    res.status(201).json({ message: 'Situación Crítica registrada', situacion });
  } catch (err) {
    res.status(500).json({ errores: ['Error al registrar la situación crítica'] });
  }
};