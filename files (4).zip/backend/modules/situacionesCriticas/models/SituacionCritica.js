const mongoose = require('mongoose');

const SituacionCriticaSchema = new mongoose.Schema({
  numeroContrato: { type: String, required: true },
  fechaSituacionCritica: { type: Date, required: true },
  situacionCritica: { type: String, required: true }
});

module.exports = mongoose.model('SituacionCritica', SituacionCriticaSchema);