const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/situacionCriticaController');

router.post('/', ctrl.crearSituacionCritica);

module.exports = router;