function validarSituacionCritica(data) {
  const errores = [];
  if (!data.numeroContrato) errores.push('No. Contrato es obligatorio');
  if (!data.fechaSituacionCritica) errores.push('Fecha Situación Crítica es obligatoria');
  if (!data.situacionCritica) errores.push('Situación Crítica es obligatoria');
  return errores;
}
module.exports = { validarSituacionCritica };