const SocialObra = require('../models/SocialObra');
const { validarSocialObra } = require('../validations/socialObraValidation');

exports.crearSocialObra = async (req, res) => {
  const errores = validarSocialObra(req.body);
  if (errores.length) return res.status(400).json({ errores });
  try {
    const socialObra = new SocialObra(req.body);
    await socialObra.save();
    res.status(201).json({ message: 'Asociación Social Obra creada', socialObra });
  } catch (err) {
    res.status(500).json({ errores: ['Error al crear la asociación'] });
  }
};