const TecnicoIDU = require('../models/TecnicoIDU');
const { validarTecnicoIDU } = require('../validations/tecnicoIDUValidation');

exports.crearTecnicoIDU = async (req, res) => {
  const errores = validarTecnicoIDU(req.body);
  if (errores.length) return res.status(400).json({ errores });
  try {
    const tecnicoIDU = new TecnicoIDU(req.body);
    await tecnicoIDU.save();
    res.status(201).json({ message: 'Asociación Técnico IDU creada', tecnicoIDU });
  } catch (err) {
    res.status(500).json({ errores: ['Error al crear la asociación'] });
  }
};