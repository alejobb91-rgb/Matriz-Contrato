const SocialIDU = require('../models/SocialIDU');
const { validarSocialIDU } = require('../validations/socialIDUValidation');

exports.crearSocialIDU = async (req, res) => {
  const errores = validarSocialIDU(req.body);
  if (errores.length) return res.status(400).json({ errores });
  try {
    const socialIDU = new SocialIDU(req.body);
    await socialIDU.save();
    res.status(201).json({ message: 'Asociación Social IDU creada', socialIDU });
  } catch (err) {
    res.status(500).json({ errores: ['Error al crear la asociación'] });
  }
};