const SocialInterventoria = require('../models/SocialInterventoria');
const { validarSocialInterventoria } = require('../validations/socialInterventoriaValidation');

exports.crearSocialInterventoria = async (req, res) => {
  const errores = validarSocialInterventoria(req.body);
  if (errores.length) return res.status(400).json({ errores });
  try {
    const socialInterventoria = new SocialInterventoria(req.body);
    await socialInterventoria.save();
    res.status(201).json({ message: 'Asociación Social Interventoría creada', socialInterventoria });
  } catch (err) {
    res.status(500).json({ errores: ['Error al crear la asociación'] });
  }
};