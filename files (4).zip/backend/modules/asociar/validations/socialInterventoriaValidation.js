function validarSocialInterventoria(data) {
  const errores = [];
  if (!data.numeroContrato) errores.push('El No. Contrato es obligatorio');
  if (!data.nombreCompleto) errores.push('El nombre completo es obligatorio');
  if (!data.celular) errores.push('El celular es obligatorio');
  if (!data.correo || !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(data.correo)) errores.push('Correo inválido');
  if (!data.memorandoAceptacion || !/^[0-9]+$/.test(data.memorandoAceptacion)) errores.push('Memorando debe ser solo números');
  return errores;
}
module.exports = { validarSocialInterventoria };