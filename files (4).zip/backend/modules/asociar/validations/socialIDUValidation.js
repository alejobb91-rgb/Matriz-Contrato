function validarSocialIDU(data) {
  const errores = [];
  if (!data.numeroContrato) errores.push('El No. Contrato es obligatorio');
  if (!data.cedulaCoordinador) errores.push('Debe elegir un coordinador social');
  if (!data.radicadoAsignacion || !/^[0-9]+$/.test(data.radicadoAsignacion)) errores.push('Radicado debe ser solo números');
  if (!data.fechaDesignacion) errores.push('La fecha es obligatoria');
  if (typeof data.activo !== "boolean") errores.push('El campo Activo es obligatorio');
  return errores;
}
module.exports = { validarSocialIDU };