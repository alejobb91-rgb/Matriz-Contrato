function validarTecnicoIDU(data) {
  const errores = [];
  if (!data.numeroContrato) errores.push('El No. Contrato es obligatorio');
  if (!data.subdireccionResponsable) errores.push('Subdirección Responsable es obligatoria');
  if (!data.nombreCompleto) errores.push('El nombre completo es obligatorio');
  if (!data.celular) errores.push('El celular es obligatorio');
  if (!data.correo || !/^[a-zA-Z0-9._%+-]+@idu\.gov\.co$/.test(data.correo)) errores.push('Correo debe ser tipo xxxx@idu.gov.co');
  return errores;
}
module.exports = { validarTecnicoIDU };