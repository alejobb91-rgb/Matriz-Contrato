const express = require('express');
const router = express.Router();
const socialIDUCtrl = require('../controllers/socialIDUController');
const socialInterventoriaCtrl = require('../controllers/socialInterventoriaController');
const socialObraCtrl = require('../controllers/socialObraController');
const tecnicoIDUCtrl = require('../controllers/tecnicoIDUController');

router.post('/social-idu', socialIDUCtrl.crearSocialIDU);
router.post('/social-interventoria', socialInterventoriaCtrl.crearSocialInterventoria);
router.post('/social-obra', socialObraCtrl.crearSocialObra);
router.post('/tecnico-idu', tecnicoIDUCtrl.crearTecnicoIDU);

module.exports = router;