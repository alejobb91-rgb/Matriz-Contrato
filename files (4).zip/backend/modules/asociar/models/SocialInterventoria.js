const mongoose = require('mongoose');

const SocialInterventoriaSchema = new mongoose.Schema({
  numeroContrato: { type: String, required: true },
  nombreCompleto: { type: String, required: true },
  celular: { type: String, required: true },
  correo: {
    type: String,
    required: true,
    match: [/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, 'Correo inválido']
  },
  memorandoAceptacion: { type: String, required: true, match: [/^[0-9]+$/, 'Solo números'] }
});

module.exports = mongoose.model('SocialInterventoria', SocialInterventoriaSchema);