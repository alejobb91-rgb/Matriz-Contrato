const mongoose = require('mongoose');

const TecnicoIDUSchema = new mongoose.Schema({
  numeroContrato: { type: String, required: true },
  subdireccionResponsable: {
    type: String,
    enum: [
      'SGDU', 'SGI', 'DTINI', 'DTP', 'DTC', 'DTCI', 'DTAI',
      'STEP', 'STED', 'STAP', 'STGSV', 'STESV', 'STEST', 'STCSV', 'STCST'
    ],
    required: true
  },
  nombreCompleto: { type: String, required: true },
  celular: { type: String, required: true },
  correo: {
    type: String,
    required: true,
    match: [/^[a-zA-Z0-9._%+-]+@idu\.gov\.co$/, 'Correo debe ser tipo xxxx@idu.gov.co']
  }
});

module.exports = mongoose.model('TecnicoIDU', TecnicoIDUSchema);