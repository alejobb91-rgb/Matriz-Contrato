const mongoose = require('mongoose');

const SocialIDUSchema = new mongoose.Schema({
  numeroContrato: { type: String, required: true },
  cedulaCoordinador: { type: String, required: true },
  radicadoAsignacion: { type: String, required: true, match: [/^[0-9]+$/, 'Solo números'] },
  fechaDesignacion: { type: Date, required: true },
  activo: { type: Boolean, default: true }
});

module.exports = mongoose.model('SocialIDU', SocialIDUSchema);