const Contrato = require('../models/Contrato');

async function guardarContrato(data) {
  const contrato = new Contrato(data);
  await contrato.save();
  return contrato;
}

module.exports = { guardarContrato };