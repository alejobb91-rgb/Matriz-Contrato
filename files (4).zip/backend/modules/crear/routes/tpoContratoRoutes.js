const express = require('express');
const router = express.Router();
const tpoContratoController = require('../controllers/tpoContratoController');

router.post('/tpo', tpoContratoController.crearTpoContrato);

module.exports = router;