const express = require('express');
const contratoCtrl = require('../controllers/crearContratoController');
const socialCtrl = require('../controllers/crearSocialController');
const router = express.Router();

router.post('/contrato', contratoCtrl.crearContrato);
router.post('/social', socialCtrl.crearSocial);

module.exports = router;