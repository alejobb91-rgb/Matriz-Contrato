function validarTpoContrato(data) {
  const errores = [];
  const patron = /^IDU-\d{4}-\d{4}$/;
  if (!data.numeroContrato || !patron.test(data.numeroContrato)) {
    errores.push('El No. Contrato es obligatorio y debe ser del tipo IDU-XXXX-YYYY');
  }
  if (!data.tipoContrato) errores.push('El tipo de contrato es obligatorio');
  if (!data.objetoContrato) errores.push('El objeto del contrato es obligatorio');
  if (!data.nombreContratista) errores.push('El nombre del contratista es obligatorio');
  if (!data.numeroContratoInterventoria || !patron.test(data.numeroContratoInterventoria)) {
    errores.push('El No. Contrato Interventoria es obligatorio y debe ser del tipo IDU-XXXX-YYYY');
  }
  if (!data.nombreContratistaInterventoria) errores.push('El nombre del contratista de interventoría es obligatorio');
  if (!data.manualInterventoria) errores.push('El manual de interventoría es obligatorio');
  if (!data.complejidad) errores.push('La complejidad es obligatoria');
  return errores;
}
module.exports = { validarTpoContrato };