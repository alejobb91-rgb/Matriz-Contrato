const mongoose = require('mongoose');

const ContratoSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  cliente: { type: String, required: true },
  fechaInicio: { type: Date, required: true },
  fechaFin: { type: Date, required: true },
  monto: { type: Number, required: true },
  estado: { type: String, default: 'Pendiente' },
  notas: String,
  tipo: { type: String, enum: ['Servicio', 'Venta', 'Alquiler'], default: 'Servicio' },
  responsable: String,
  firmado: { type: Boolean, default: false }
});

module.exports = mongoose.model('Contrato', ContratoSchema);