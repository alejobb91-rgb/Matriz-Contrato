const mongoose = require('mongoose');

const TpoContratoSchema = new mongoose.Schema({
  numeroContrato: { type: String, required: true, unique: true }, // IDU-XXXX-YYYY
  tipoContrato: {
    type: String,
    enum: ['Conservación', 'Troncal', 'Vial', 'E.Previas', 'E&D'],
    required: true
  },
  objetoContrato: { type: String, required: true },
  nombreContratista: { type: String, required: true },
  numeroContratoInterventoria: { type: String, required: true }, // IDU-XXXX-YYYY
  nombreContratistaInterventoria: { type: String, required: true },
  manualInterventoria: {
    type: String,
    enum: [
      'Manual Interventoria V6',
      'Manual Interventoria V7',
      'Manual Interventoria V8',
      'Manual Interventoria V9',
      'Manual Interventoria V10'
    ],
    required: true
  },
  complejidad: {
    type: String,
    enum: ['Baja', 'Media', 'Alta'],
    required: true
  }
});

module.exports = mongoose.model('TpoContrato', TpoContratoSchema);