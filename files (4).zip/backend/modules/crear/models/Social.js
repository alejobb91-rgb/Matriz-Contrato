const mongoose = require('mongoose');

const SocialSchema = new mongoose.Schema({
  cedula: { type: String, required: true, unique: true },
  nombre: { type: String, required: true },
  celular: { type: String, required: true },
  correo: {
    type: String,
    required: true,
    match: [/^[a-zA-Z0-9._%+-]+@idu\.gov\.co$/, 'Correo debe ser tipo xxxx@idu.gov.co'],
    unique: true
  }
});

module.exports = mongoose.model('Social', SocialSchema);