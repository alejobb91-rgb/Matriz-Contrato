const { validarContrato } = require('../validations/contratoValidation');
const { guardarContrato } = require('../services/contratoService');

exports.crearContrato = async (req, res) => {
  const errores = validarContrato(req.body);
  if (errores.length) {
    return res.status(400).json({ errores });
  }
  const contrato = await guardarContrato(req.body);
  res.status(201).json({ message: 'Contrato creado exitosamente', contrato });
};