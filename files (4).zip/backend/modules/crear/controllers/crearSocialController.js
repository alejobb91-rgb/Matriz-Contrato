const Social = require('../models/Social');
const { validarSocial } = require('../validations/socialValidation');

exports.crearSocial = async (req, res) => {
  const errores = validarSocial(req.body);
  if (errores.length) {
    return res.status(400).json({ errores });
  }
  try {
    const social = new Social(req.body);
    await social.save();
    res.status(201).json({ message: 'Registro social creado exitosamente', social });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(400).json({ errores: ['La cédula o el correo ya existen'] });
    }
    res.status(500).json({ errores: ['Error al crear el registro social'] });
  }
};