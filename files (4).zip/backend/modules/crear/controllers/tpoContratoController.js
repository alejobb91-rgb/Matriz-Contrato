const TpoContrato = require('../models/TpoContrato');
const { validarTpoContrato } = require('../validations/tpoContratoValidation');

exports.crearTpoContrato = async (req, res) => {
  const errores = validarTpoContrato(req.body);
  if (errores.length) {
    return res.status(400).json({ errores });
  }
  try {
    const tpoContrato = new TpoContrato(req.body);
    await tpoContrato.save();
    res.status(201).json({ message: 'Contrato TPO creado exitosamente', tpoContrato });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(400).json({ errores: ['El No. Contrato ya existe'] });
    }
    res.status(500).json({ errores: ['Error al crear el contrato'] });
  }
};