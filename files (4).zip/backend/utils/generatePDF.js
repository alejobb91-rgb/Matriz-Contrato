const PDFDocument = require('pdfkit');

function generatePDF(contract, res) {
  const doc = new PDFDocument();
  doc.pipe(res);

  doc.fontSize(20).text('Contrato', { align: 'center' });
  doc.moveDown();
  doc.fontSize(12)
    .text(`Nombre: ${contract.nombre}`)
    .text(`Cliente: ${contract.cliente}`)
    .text(`Fecha de inicio: ${contract.fechaInicio?.toISOString().split('T')[0]}`)
    .text(`Fecha de fin: ${contract.fechaFin?.toISOString().split('T')[0]}`)
    .text(`Monto: $${contract.monto}`)
    .text(`Estado: ${contract.estado}`)
    .moveDown()
    .text(`Notas:`)
    .text(contract.notas || '-');
  doc.end();
}

module.exports = generatePDF;